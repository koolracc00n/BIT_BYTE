import { ArrowDownRight, ArrowRight, Sparkles, Utensils, X } from 'lucide-react'
import { useState } from 'react'
import SearchBar from './components/SearchBar'
import FoodCard from './components/FoodCard'
import { foodData } from './data/food'
import { searchFoods } from './services/search'
import type { FoodResult } from './types'

const categories = [
  { label: '🥑 Nutrition', query: 'nutrition' },
  { label: '🍜 Recipes', query: 'recipe' },
  { label: '🥩 Protein', query: 'protein' },
  { label: '🍓 Ingredients', query: 'ingredient' },
  { label: '🍕 Food science', query: 'food science' },
]

export default function App() {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<FoodResult[]>([])
  const [searched, setSearched] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function runSearch(value: string) {
    setQuery(value)
    setSearched(true)
    setLoading(true)
    setError('')
    try {
      const response = await searchFoods(value)
      setResults(response.results)
    } catch {
      setError('Search could not be completed. Check the backend connection and try again.')
      setResults([])
    } finally {
      setLoading(false)
    }
  }

  function resetSearch() {
    setQuery('')
    setResults([])
    setSearched(false)
    setError('')
  }

  return (
    <main className="site-shell">
      <div className="ambient ambient--one" />
      <div className="ambient ambient--two" />

      <header className="navbar">
        <a className="brand" href="/" onClick={(event) => { event.preventDefault(); resetSearch() }}>
          <span className="brand-mark"><Utensils size={19} strokeWidth={2.7} /></span>
          <span>BITBYTE<span className="brand-dot">.</span></span>
        </a>
        <nav className="nav-links" aria-label="Main navigation">
          <a href="#discover">Discover</a>
          <a href="#recipes" onClick={() => runSearch('recipe')}>Recipes</a>
        </nav>
        <button className="nav-avatar" aria-label="User profile">B</button>
      </header>

      {!searched ? (
        <section className="hero">
          <div className="hero-kicker"><span className="kicker-dot" /> THE FOOD UNIVERSE <span className="kicker-line" /></div>
          <h1>FOOD IS MORE<br /><span>THAN JUST FOOD.</span></h1>
          <div className="hero-subline">
            <p>Explore. Eat. Understand.</p>
            <span>Your curiosity deserves a better search engine.</span>
          </div>

          <div className="hero-art">
            <div className="art-sticker sticker--tomato">TASTE<br />THE<br />WORLD</div>
            <div className="art-sticker sticker--star"><Sparkles size={27} /> GOOD<br />FOOD<br />ENERGY</div>
            <div className="food-photo photo--main">
              <img src="https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=1200&q=90" alt="Colourful food spread" />
              <span className="photo-label">A LITTLE BIT OF EVERYTHING</span>
            </div>
            <div className="food-photo photo--small">
              <img src="https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&w=700&q=85" alt="Fresh salad bowl" />
            </div>
            <div className="art-note"><span>01 / 05</span><span>DISCOVER SOMETHING DELICIOUS <ArrowDownRight size={14} /></span></div>
          </div>

          <div className="home-search">
            <SearchBar onSearch={runSearch} />
            <div className="search-hint"><span>TRY SEARCHING</span><span>anything edible, really ↗</span></div>
          </div>

          <div className="category-pills">
            {categories.map((category) => (
              <button key={category.label} onClick={() => runSearch(category.query)}>{category.label}</button>
            ))}
          </div>
        </section>
      ) : (
        <section className="results-page">
          <div className="results-top">
            <a className="brand brand--small" href="/" onClick={(event) => { event.preventDefault(); resetSearch() }}>
              <span className="brand-mark"><Utensils size={17} /></span><span>BITBYTE<span className="brand-dot">.</span></span>
            </a>
            <SearchBar initialValue={query} compact onSearch={runSearch} />
            <button className="icon-button result-close" onClick={resetSearch} aria-label="Back to home"><X size={19} /></button>
          </div>
          <div className="result-tabs">
            <span className="tab-active">All results</span><button onClick={() => runSearch(`${query} nutrition`)}>Nutrition</button><button onClick={() => runSearch(`${query} recipe`)}>Recipes</button><button onClick={() => runSearch(`${query} protein`)}>Protein</button>
          </div>
          <div className="results-content">
            <div className="results-heading">
              <div><span className="eyebrow">SEARCHING THE FOOD UNIVERSE</span><h2>Results for <em>“{query}”</em></h2></div>
              <button className="text-button" onClick={resetSearch}>New search <ArrowRight size={15} /></button>
            </div>
            <div className="ai-summary">
              <div className="ai-summary__top"><span><Sparkles size={15} /> BITBYTE INTELLIGENCE</span><span className="demo-tag">PREVIEW</span></div>
              <h3>Good things start with curiosity.</h3>
              <p>This is the first search experience. Results are currently powered by a small local food dataset. Next, we’ll connect real nutrition and recipe sources, then add grounded AI summaries.</p>
            </div>
            {error && <p className="error-message">{error}</p>}
            {loading ? <div className="loading-state"><span className="loader" /> Searching the food universe…</div> : (
              results.length ? (
                <div className="result-grid">{results.map((item) => <FoodCard key={item.id} item={item} />)}</div>
              ) : (
                <div className="empty-state"><span>¯\\_(ツ)_/¯</span><h3>No food found. Yet.</h3><p>Try “paneer”, “protein”, “oats” or “food science”.</p></div>
              )
            )}
          </div>
        </section>
      )}

      <section className="manifesto" id="discover">
        <div className="manifesto__left"><span className="eyebrow">BITBYTE INTELLIGENCE <Sparkles size={14} /></span><h2>EAT<br /><em>SMARTER.</em></h2></div>
        <div className="manifesto__right"><p>Not another recipe website.<br /><strong>A whole new way to explore food.</strong></p><span className="manifesto-arrow"><ArrowRight size={25} /></span></div>
      </section>

      {!searched && (
        <section className="explore-section" id="recipes">
          <div className="section-head"><div><span className="eyebrow">A WORLD ON YOUR PLATE</span><h2>Explore the delicious <em>chaos.</em></h2></div><span className="section-index">01 — 04</span></div>
          <div className="explore-grid">
            {foodData.slice(0, 4).map((item, index) => (
              <button className={`explore-tile explore-tile--${index + 1}`} key={item.id} onClick={() => runSearch(item.title)}>
                <img src={item.image} alt="" loading="lazy" />
                <span className="tile-number">0{index + 1}</span>
                <span className="tile-title">{['Food discovery', 'Nutrition explorer', 'Recipe universe', 'Ingredient library'][index]}</span>
                <span className="tile-arrow"><ArrowRight size={17} /></span>
              </button>
            ))}
          </div>
        </section>
      )}

      <footer className="footer"><a className="brand brand--small" href="#" onClick={(event) => { event.preventDefault(); resetSearch() }}>BITBYTE<span className="brand-dot">.</span></a><span>MADE FOR THE CURIOUS & HUNGRY.</span><span>© BITBYTE 2026</span></footer>
    </main>
  )
}