export type FoodCategory = 'Nutrition' | 'Recipes' | 'Protein' | 'Ingredients' | 'Food science'

export interface FoodResult {
  id: string
  title: string
  category: FoodCategory
  description: string
  image: string
  tags: string[]
  calories?: number
  protein?: number
}

export interface SearchResponse {
  query: string
  total: number
  results: FoodResult[]
}