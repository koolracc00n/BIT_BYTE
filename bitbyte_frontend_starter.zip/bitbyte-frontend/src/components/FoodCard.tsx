import { ArrowUpRight, Flame, Tags } from 'lucide-react'
import type { FoodResult } from '../types'

export default function FoodCard({ item }: { item: FoodResult }) {
  return (
    <article className="food-card">
      <div className="food-card__image-wrap">
        <img src={item.image} alt="" className="food-card__image" loading="lazy" />
        <span className="food-card__category">{item.category}</span>
        <button className="food-card__open" aria-label={`Open ${item.title}`}>
          <ArrowUpRight size={18} />
        </button>
      </div>
      <div className="food-card__body">
        <h3>{item.title}</h3>
        <p>{item.description}</p>
        {(item.calories !== undefined || item.protein !== undefined) && (
          <div className="food-card__facts">
            {item.calories !== undefined && <span><Flame size={14} /> {item.calories} kcal</span>}
            {item.protein !== undefined && <span><Tags size={14} /> {item.protein}g protein</span>}
          </div>
        )}
      </div>
    </article>
  )
}