import axios from 'axios'
import type { SearchResponse } from '../types'
import { searchFood } from '../data/food'

const API_BASE_URL = import.meta.env.VITE_API_URL

export async function searchFoods(query: string): Promise<SearchResponse> {
  // If the backend URL is configured, use the real API.
  if (API_BASE_URL) {
    const response = await axios.get<SearchResponse>(`${API_BASE_URL}/api/search`, {
      params: { q: query },
    })
    return response.data
  }

  // Frontend-only fallback keeps search interactive before backend work begins.
  const results = searchFood(query)
  return { query, total: results.length, results }
}