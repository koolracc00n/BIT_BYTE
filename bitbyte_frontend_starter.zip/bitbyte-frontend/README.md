# BITBYTE frontend

React + TypeScript + Vite frontend for the BITBYTE food search experience.

## Run

```bash
npm install
npm run dev
```

## Current search behavior

- Search is functional using a small local demo dataset.
- Search results are ranked by title, tags, category and description.
- To connect a backend, set `VITE_API_URL` in `.env.local`.
- Expected backend endpoint: `GET /api/search?q=<query>`
- Expected response shape:

```json
{
  "query": "paneer",
  "total": 1,
  "results": [
    {
      "id": "paneer",
      "title": "Paneer",
      "category": "Nutrition",
      "description": "Food description",
      "image": "https://example.com/image.jpg",
      "tags": ["paneer", "protein"],
      "calories": 265,
      "protein": 18
    }
  ]
}
```

Demo data is not authoritative nutrition guidance. Real nutrition values and source citations will be connected in the backend phase.
